$Id: README.txt 50858 2008-10-21 19:04:12Z cxh $
 See package.html
