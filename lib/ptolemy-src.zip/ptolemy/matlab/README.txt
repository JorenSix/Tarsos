$Id: README.txt 35713 2004-12-29 03:56:50Z cxh $
See package.html
