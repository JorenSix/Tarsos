$Id: README.txt 35715 2004-12-29 03:56:55Z cxh $
See package.html
