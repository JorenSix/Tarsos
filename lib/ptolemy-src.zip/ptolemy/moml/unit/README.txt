$Id: README.txt 49505 2008-05-23 14:27:31Z cxh $
See package.html
