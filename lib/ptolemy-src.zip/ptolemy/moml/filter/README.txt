$Id: README.txt 36786 2005-03-14 17:54:10Z cxh $
See package.html
