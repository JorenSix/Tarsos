package jass.contact;
import jass.engine.*;
import jass.generators.*;

public interface ImpactSlideRollForce extends ImpactForce, SlideForce, RollForce {
}


