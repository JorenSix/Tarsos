package jass.engine;

/**
   Thrown when can't add.
   @author Kees van den Doel (kvdoel@cs.ubc.ca)
*/
public class SinkIsFullException extends Exception {
}

